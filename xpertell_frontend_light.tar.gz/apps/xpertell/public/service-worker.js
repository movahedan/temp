self.addEventListener("push", function (event) {
    const data = event.data.json()
    self.registration.showNotification(data.title, {
        // icon: data.icon,
        body: data.body,
        // image: data.image,
        // tag: data.tag,
        // vibrate: [100, 50, 100],
        // badge: data.badge,
        // requireInteraction: data.requireInteraction,
        // renotify: data.renotify,
        // data: {url: data.url},
    })

})

self.onnotificationclick = event => {
    event.notification.close()
    event.waitUntil(clients.matchAll({type: "window"})
        .then(_ => clients.openWindow && clients.openWindow(event.notification.data.url)))
}

self.addEventListener("message", (event) => {
    if (event.data && event.data.type === "SKIP_WAITING") {
        self.skipWaiting()
    }
})

self.addEventListener("install", () => self.skipWaiting())
